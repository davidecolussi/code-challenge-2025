import { appendFileSync, createReadStream, writeFileSync } from "fs";
import * as path from "path";
import { createInterface } from "readline";

const inputBasePath = "./input";
const outputBasePath = "./output";
const inputFile = "0-demo.txt";

const line_counter = (
  (i = 0) =>
  () =>
    ++i
)();
const lineReader = createInterface({
  input: createReadStream(path.join(inputBasePath, inputFile)),
  crlfDelay: Infinity,
});

let budget,
  numResources,
  numTurns,
  resources = {},
  turns = [];

lineReader.on("line", (line, index = line_counter()) => {
  // Process the line.
  const values = line.split(" ");

  if (index === 1) {
    budget = Number(values[0]);
    numResources = Number(values[1]);
    numTurns = Number(values[2]);
  } else if (index <= numResources + 1) {
    resources[values[0]] = {
      id: values[0],
      activationCost: Number(values[1]),
      periodicCost: Number(values[2]),
      consecutiveTurns: Number(values[3]),
      recoverTurns: Number(values[4]),
      maxTurns: Number(values[5]),
      numPowered: Number(values[6]),
      specialEffects: values[7],
      specialEffectsValue: values[8] && Number(values[8]), // optional
      status: {
        active: false,
        remainingTurns: Number(values[5]),
        remainingActiveTurns: Number(values[3]),
        remainingRecoverTurns: undefined,
      },
    };
  } else {
    turns.push({
      min: Number(values[0]),
      max: Number(values[1]),
      profit: Number(values[2]),
    });
  }
});

lineReader.on("close", async () => {
  console.log("reader closed");
  console.log(budget, numResources, numTurns);
  console.log(resources, turns);

  writeFileSync(path.join(outputBasePath, inputFile), "");
  turns.forEach(({ min, max, profit }, i) => {
    Object.values(resources)
      // aggiornare i contatori attive
      .forEach((r) => {
        if (r.status.active) {
          r.status.remainingTurns--;
          r.status.remainingActiveTurns--;
          if (r.status.remainingTurns === 0) {
            r.status.active = false;
          } else if (r.status.remainingActiveTurns === 0) {
            r.status.active = false;
            r.status.recoverTurns = r.recoverTurns;
          } else {
            // applica costi fissi
            budget -= r.periodicCost;
          }
        } else {
          // aggiornare i contatori non attive
          if (r.status.recoverTurns !== undefined) {
            r.status.recoverTurns--;
          }
        }
      });

    // decisione su quali attivare
    const inBuget = getResourcesInBudget(min, max, profit);
    if (!inBuget.length) {
      return;
    }

    // attiva la prima
    resources[inBuget[0].id].status.active = true;
    appendFileSync(
      path.join(outputBasePath, inputFile),
      `${i} 1 ${inBuget[0].id}\n`
    );
  });
});

function getProfit(additionalResources, tm, tx, tr) {
  const n = Object.values(resources)
    .filter((r) => r.status.active)
    .concat(additionalResources)
    .reduce((count, r) => count + r.numPowered, 0);
  return n >= tm ? Math.min(n, tx) * tr : 0;
}

function getResourcesInBudget(tm, tx, tr) {
  return Object.values(resources)
    .filter(
      (r) =>
        !r.status.active &&
        (r.status.recoverTurns === undefined || r.status.recoverTurns === 0) &&
        r.status.remainingTurns > 0
    )
    .filter((r) => {
      const profit = getProfit([r], tm, tx, tr);
      return budget + profit - r.activationCost - r.periodicCost >= 0;
    });
}
